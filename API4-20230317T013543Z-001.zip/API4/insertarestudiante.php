<?php
if($_SERVER["REQUEST_METHOD"]=="POST"){
    require_once 'conexion.php';
    $nombres = $_POST["Nombres"];
    $apellidos = $_POST["Apellidos"];
    $carrera = $_POST["Carrera"];
    $año = $_POST["Año"];
    $my_query = "insert into Estudiante(Nombres, Apellidos, Carrera, Año) 
    values('".$nombres."', '".$apellidos."' , '".$carrera."' , '".$año."')";
    $result = $mysql -> query($my_query);
    if($result == true){
        echo "Registro guardado satisfactoriamente...";
    }else{
        echo "Error al guardar registro...";
    }
}else{
    echo"Error desconocido";
}
?>