<?php

require_once 'conexion.php';

$data = json_decode(file_get_contents("php://input"), true);

// Obtener el identificador del registro a actualizar desde la URL
$id = $_GET['Id'];

$sql = "UPDATE Estudiante SET Nombres='" . $data["Nombres"] . "', Apellidos='" . $data["Apellidos"] . "', Carrera='" . $data["Carrera"] ."', Año='" . $data["Año"] ."' WHERE Id=" . $id;
$resultado=$mysql->query($sql);

if ($resultado==true) {
    echo "Datos actualizados correctamente.";
} else {
    echo "Error al actualizar los datos: ";
}




?>